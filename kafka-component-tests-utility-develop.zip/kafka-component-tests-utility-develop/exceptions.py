
class KafkaConfigMissingMinimumConfig(Exception):
    pass