from kafka.admin import KafkaAdminClient, NewTopic
from steps.utilities.kafka.exceptions import KafkaConfigMissingMinimumConfig
import time
import logging

class AdminClient:
    def __init__(self, config, level_logging=logging.DEBUG):
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(level_logging)
        if not config.get("bootstrap_servers", None):
            raise KafkaConfigMissingMinimumConfig
        try:
            self.__admin = KafkaAdminClient(**config)
        except Exception as e:
            self.logger.error(f"Error - {e}")

    @property
    def admin(self):
        return self.__admin
    
    def create_topic(self, topic_config):
        created = True
        try:
            new_topic = NewTopic(**topic_config)
            self.admin.create_topics(new_topics=[new_topic], validate_only=False)
        except Exception as e:
            self.logger.error(f'An exception occured while creating topic [{topic_config.get("name", "No name set on config")}] - {e}')
            created = False
        return created

    def topic_exists(self, topic_name):
        topics = self.admin.list_topics()
        return topic_name in topics

    def delete_topic(self, topic_name):
        try:
            self.admin.delete_topics([topic_name], timeout_ms=2000)
            time.sleep(5)  # Wait for topic deleted completely
        except Exception as e:
            self.logger.error(f'An exception occured while deleting topic [{topic_name}] - {e}. you might want to set delete.topic.enable=true')

    def close(self):
        self.logger.info("Closing Kafka Admin Client connection...")
        self.admin.close()

if __name__ == "__main__":
    config = {
        "bootstrap_servers": "kafka:9092",
        "client_id": "atf"
    }
    admin = AdminClient(config)

    admin.create_topic("Test")