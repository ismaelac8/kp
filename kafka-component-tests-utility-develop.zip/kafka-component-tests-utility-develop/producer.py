from kafka import KafkaProducer

import logging
from steps.utilities.kafka.exceptions import KafkaConfigMissingMinimumConfig
import time
from kafka.errors import UnknownTopicOrPartitionError

logger = logging.getLogger(__name__)

class Producer:

    def __init__(self, config:dict):
        if not config.get("bootstrap_servers", None):
            raise KafkaConfigMissingMinimumConfig
        self.__producer = KafkaProducer(**config)
    
    @property
    def producer(self):
        return self.__producer
    
    def __on_produce_success(self, data):
        logger.info(f"Produced with success - Topic: {data.topic} - Partition: {data.partition} - Offset: {data.offset}")

    def __on_produce_err(self, exc):
        logger.error(f"Failed to producer - {exc}")

    def produce(self, topic, message, key = 1):
        """
        Pushes 'message' into 'topic'
        """
        try:    
            self.producer.send(topic, value = message if message else {"id": str(uuid.uuid4())}, key = key)
            self.producer.flush(timeout=5) #.add_callback(self.__on_produce_success).add_errback(self.__on_produce_err)

        except Exception as e:
            logger.error(f"An exception occured while pushing message - {e}")

    def close(self):
        self.producer.close()

if __name__ == "__main__":
    config = {
        "bootstrap_servers": "kafka:9092",
        "value_serializer": lambda v: v.encode('utf-8'),
        "key_serializer": lambda v: str(v).encode(),
        "acks": 0
    }
    producer = Producer(config)

    producer.produce("test-topic", "TEST-Produce to topic")

    producer.close()