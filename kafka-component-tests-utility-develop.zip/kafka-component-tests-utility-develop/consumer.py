from kafka import KafkaConsumer, TopicPartition
from steps.utilities.kafka.exceptions import KafkaConfigMissingMinimumConfig
import time
from kafka.errors import UnknownTopicOrPartitionError

import logging

logger = logging.getLogger(__name__)

CONSUME_TIMEOUT = 3 # Maximum time to block waiting for message, event or callback

class Consumer:
    def __init__(self, config:dict):
        if not config.get("bootstrap_servers", None):
            raise KafkaConfigMissingMinimumConfig
        try:
            self.__consumer = KafkaConsumer(**config)
        except Exception as e:
            logger.error(f"Failed connection to broker - {e}")
    

    @property        
    def consumer(self):
        return self.__consumer
    
    @property
    def connected(self):
        return self.consumer.bootstrap_connected()

    def subscribe(self, topics:list):
        self.consumer.subscribe(topics)

    def unsubscribe(self):
        self.consumer.unsubscribe()
                        
    def consume_latest(self, topic, partition_id=0):
        """
        Gets latest message pushed into topic on specific partition
        """
        latest_message = None
        try:
            self.subscribe([topic])
            partition = TopicPartition(topic, partition_id)
            end_offset = self.consumer.end_offsets([partition])
            self.consumer.seek(partition,list(end_offset.values())[0]-1)
            latest_message = next(self.consumer)
            return latest_message

        except Exception as e:
            logger.error(f"Error while trying to consume latest message produced on topic [{topic}] - {e}")
        
    
    def close(self):
        self.consumer.close()

if __name__ == "__main__":
    config = {
        "bootstrap_servers": "kafka:9092",
        "enable_auto_commit": True,
        "auto_offset_reset": "latest",
        "request_timeout_ms": 3*1000
    }
    consumer = Consumer(config)

    consumer.consume_latest("test-topic")
    consumer.close()