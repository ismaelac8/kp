from kafka import KafkaConsumer,KafkaProducer
import logging

logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', level=logging.DEBUG)

class KafkaProduceConsume:
    def __init__(self,kafka_bootstrap_server):
        self.kafka_bootstrap_server = kafka_bootstrap_server
        self.kafka_topic = {
                            'topic_ps_cdr_medium': 'DEV-FT-Topic-Cdr-Diameterps-Medium',
                            'topic_cs_cdr': 'DEV-FT-Topic-Cdr-Diametercs',
                            'topic_sms_cdr': 'DEV-FT-Topic-Cdr-Sms',
                            'simEvents': 'DEV-FT-Topic-Med-Simevents2'
        }

    def produce_message(self,topic_name,test_data):
        try:
            data =str(test_data["cdr"])
            kafka_bytes = data.encode('utf-8')
            logging.info(f"publishing data {data}")
            logging.info("Producing to Kafka Servers: {} Topic: {} ".format(self.kafka_bootstrap_server,
                                                                                    self.kafka_topic[topic_name]))
            producer = KafkaProducer(bootstrap_servers=self.kafka_bootstrap_server,
                                         acks='all',
                                         max_block_ms=1200000)
            ack = producer.send(self.kafka_topic[topic_name], kafka_bytes)
            logging.info(f"ack :{ack}")
            ack.get(timeout=60)
            producer.flush()
            producer.close()
        except Exception as E:
            raise Exception(f"An Exception occurred during publishing to kafka : [{E}]")

    def open_consumer(self,topic):
        logging.info(
            "Consuming from Kafka Servers {} and Topic {} ".format(self.kafka_bootstrap_server,self.kafka_topic[topic]
            ))
        try:
            self.kafka_consumer = KafkaConsumer(self.kafka_topic[topic],
                                                    bootstrap_servers=self.kafka_bootstrap_server,
                                                    enable_auto_commit=True,
                                                    auto_offset_reset='latest',
                                                    request_timeout_ms=120000,
                                                    metadata_max_age_ms=120000)
            
        
        except Exception as E:
            raise Exception(f"An Exception occurred while subscribing as kafka consumer : [{E}]")
        
    def get_next_record(self):
        try:
            logging.info("Fetching next record from kafka")
            message = self.kafka_consumer.poll(timeout_ms=10000, max_records=1)
            if message:
                logging.info("Poll returned message: {}".format(message))
                for topic_data, consumer_records in message.items():
                    for consumer_record in consumer_records:
                        record = str(consumer_record.value.decode('utf-8'))
                        if record:
                            logging.info('Found record: {} in message'.format(record))
                        else:
                            logging.info('No records found in message')
                            return None
            else:
                logging.info('No message returned from kafka')
                return None

            return record

        except Exception as E:
            raise Exception(f"An Exception occurred while fetching records from kafka : [{E}]")
        
    def close_consumer(self):
        try:
            logging.info("Closing kafka consumer")
            self.kafka_consumer.close()

        except Exception as E:
            raise Exception(f"An Exception occurred while closing kafka consumer : [{E}]")

    def clear_messages(self):
        try:
            flag = False
            count = 0
            while not flag:
                kafka_response = self.kafka_consumer.poll(timeout_ms=10000, max_records=1)
                if not kafka_response:
                    flag = True
                    continue
                count += 1
            logging.info("Number of CDR's read from kafka :{}".format(count))
        except Exception as E:
            raise Exception(f"An Exception occurred while clearing kafka cdr : [{E}]")
        
    def produce_consume(self,publish_topic,consume_topic,test_data):
        try:
            self.open_consumer(consume_topic)
            self.clear_messages()
            self.produce_message(publish_topic,test_data)
            response_data = self.get_next_record()
            self.close_consumer()
            return response_data
        except Exception as E:
            raise Exception(f"An Exception occurred during kafka produce and consume : [{E}]")